MOBILE BIRTHDAY WEBSITE
1. Extract the ZIP.
2. Open index.html in a browser.
3. Replace the text in index.html with your own names/messages.
4. Tap the photo boxes to add photos from your phone.
5. Upload the folder to any static hosting service to make it public.

This prototype is designed mobile-first and follows the purple/gold birthday style from the reference video.
